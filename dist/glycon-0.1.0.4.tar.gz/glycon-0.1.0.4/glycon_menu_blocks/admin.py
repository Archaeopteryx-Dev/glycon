from django.contrib import admin

from glycon_menu_blocks.models import MenuBlock


admin.site.register(MenuBlock)
