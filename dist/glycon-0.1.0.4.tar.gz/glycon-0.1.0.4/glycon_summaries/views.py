from django.shortcuts import render

def summary_page(request, viewname):
    return