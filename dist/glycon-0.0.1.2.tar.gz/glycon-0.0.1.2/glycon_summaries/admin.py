from django.contrib import admin

from glycon_summaries.models import Summary, SummaryBlock


admin.site.register(Summary)
admin.site.register(SummaryBlock)
