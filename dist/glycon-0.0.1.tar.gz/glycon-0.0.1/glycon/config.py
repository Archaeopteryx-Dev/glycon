SITENAME = "Ben Collier"
GLYCON_MEDIA_URL = "/media/"